<?php

class Ghost_Service_Exception extends Ghost_Exception {
  
}
